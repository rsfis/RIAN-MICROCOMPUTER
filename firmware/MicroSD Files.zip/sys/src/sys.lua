local user_login_bg = Sprite("/sys/img/user_login_bg.png", 480, 320)
local gothambold_font = Font("/sys/fonts/Gotham Bold.bin")

-- FPS
local fps = 0
local frameCount = 0
local lastTime = os.clock()

function loop()
   while true do
      local currentTime = os.clock()
      frameCount = frameCount + 1

      -- Atualiza FPS a cada 1 segundo
      if currentTime - lastTime >= 1 then
         collectgarbage("collect")
         fps = frameCount
         frameCount = 0
         lastTime = currentTime
         --print("FPS:", fps)
         --print("Temperature: ", OS_GetCPUTemperature())
         --print("Free Memory: ", OS_GetFreeHeapMemory())
         --print("Memory Size: ", OS_GetMemorySize())
         --print("RTC: ", OS_GetTime():toString("%d/%m/%Y - %H:%M:%S"))
         --print("Lua Heap Memory Usage: ", OS_GetLuaVMHeapMemoryUsage())
      end

      Display_ClearScreen()

      user_login_bg:draw(0, 0)
      gothambold_font:drawString(OS_GetUserUsername(), 148, 150, 20, 255, 255, 255)

      Display_UpdateScreen()
   end
end

function start()
   loop()
end

start()
endProgram()
